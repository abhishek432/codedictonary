package com.abhiteshh.codedictonary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class homes extends AppCompatActivity {
Button button1,button2,button,notes;
TextView tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homes);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        button=(Button)findViewById(R.id.button);
        notes=(Button)findViewById(R.id.notes);
        tv2=(TextView)findViewById(R.id.tv2);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(homes.this, MainActivity.class);
            startActivity(i);}
        });



        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(homes.this,runActivity.class);       startActivity(i);
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(homes.this,cmdActivity.class);
                startActivity(i);}
        });



tv2.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent=new Intent(homes.this,devActivity.class);
        startActivity(intent);
    }
});

notes.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent i=new Intent(homes.this,notesActivity.class);
        startActivity(i);
    }
});
    }
}