package com.abhiteshh.codedictonary;

import androidx.appcompat.app.AppCompatActivity;
import android.net.Uri;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

public class runActivity extends AppCompatActivity {
    WebView web1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_run);
       /* web1=(WebView)findViewById(R.id.web1);
        web1.loadUrl("https://replit.com/@AbhishekTiwari2/GigaSpryError#main.sh");
        web1.getSettings().getJavaScriptEnabled();*/

        Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.termux&hl=en_US&gl=US");
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(intent);

    }


}
